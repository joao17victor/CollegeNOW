<?php
		require("Funcionario.php");
		require("Supervisor.php");
		require("Gerente.php");
		require("Secretaria.php");
		
$Agata = new Secretaria("Agata Willians",20,"13/10/2019","135.135.125-10","AgataWillians@AvTech.com");

$Agata->dadosFuncionario();
$Agata->dadosFinanceiro();

$Afonso = new Gerente("Afonso Stradsman",22,"13/10/2013","034.783.892-83","AfonsoStradsman@AvTech.com");
$Afonso->dadosFuncionario();
$Afonso->dadosFinanceiro();

$Stuart = new Supervisor("Stuart Kovosky",45,"13/10/2015","423.875.368-24","StuartKovosky@AvTech.com");
$Stuart->dadosFuncionario();
$Stuart->dadosFinanceiro();
?>