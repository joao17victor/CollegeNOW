package com.example.buildplanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {

    private Button NossaHistoria;
    private Button MenuApp;
    private Button Sobre;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NossaHistoria = findViewById(R.id.btnStories);
        MenuApp = findViewById(R.id.btnMenu);
        Sobre = findViewById(R.id.btnSobre);


        NossaHistoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,NossaHistoria.class));


            }
        });

        MenuApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,MenuApp.class));
            }
        });

        Sobre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,Sobre.class));
            }
        });
    }
}
