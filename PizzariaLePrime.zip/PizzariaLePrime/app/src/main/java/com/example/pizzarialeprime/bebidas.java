package com.example.pizzarialeprime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class bebidas extends AppCompatActivity {

    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bebidas);


        lista = findViewById(R.id.listaID);
        Bundle dado = getIntent().getExtras();
        String nome ="Refrigerante";
        String nome1 ="Suco";
        String nome2 ="Vodka";
        String nome3 ="Cerveja";
        String nome4 ="Vinho";


        ArrayList<String> bebidas = new ArrayList<String>();
        bebidas.add(nome);
        bebidas.add(nome1);
        bebidas.add(nome2);
        bebidas.add(nome3);
        bebidas.add(nome4);

        ArrayAdapter<String> adptador = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,bebidas

        );//fim do arrayadapter

        lista.setAdapter(adptador);



    }
}
