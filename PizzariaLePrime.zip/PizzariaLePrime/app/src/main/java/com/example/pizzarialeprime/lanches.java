package com.example.pizzarialeprime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class lanches extends AppCompatActivity {

    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lanches);

        lista = findViewById(R.id.lvlanchesID);
        Bundle dado = getIntent().getExtras();
        String nome ="Espeto de porco";
        String nome1 ="Pastel";
        String nome2 ="Coxinha";
        String nome3 ="Pamonha";
        String nome4 ="Salgado";


        ArrayList<String> lanches = new ArrayList<String>();
        lanches.add(nome);
        lanches.add(nome1);
        lanches.add(nome2);
        lanches.add(nome3);
        lanches.add(nome4);

        ArrayAdapter<String> adptador = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,lanches

        );//fim do arrayadapter

        lista.setAdapter(adptador);
    }
}
