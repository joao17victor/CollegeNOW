package com.example.pizzarialeprime;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageButton bebidas;
    private ImageButton combos;
    private ImageButton lanches;
    private ImageButton tipos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bebidas = findViewById(R.id.bebidasID);
        combos = findViewById(R.id.combosID);
        lanches = findViewById(R.id.lanchesID);
        tipos = findViewById(R.id.tiposID);


        bebidas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,bebidas.class));
            }
        });

        combos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,combus.class));
            }
        });
        lanches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,lanches.class));
            }
        });

        tipos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this,tipos.class));
            }
        });
    }
}
