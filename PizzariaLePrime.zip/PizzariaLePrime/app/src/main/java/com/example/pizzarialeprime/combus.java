package com.example.pizzarialeprime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class combus extends AppCompatActivity {

    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combus);

        lista = findViewById(R.id.lvcombosID);
        Bundle dado = getIntent().getExtras();
        String nome ="Refrigerante + Hamburguer + batata";
        String nome1 ="Suco + pizza 1 sabor + batata";
        String nome2 ="Vodka + pizza 2 sabor + batata";
        String nome3 ="Cerveja + pizza 3 sabor + batata";
        String nome4 ="Vinho + pizza 5 sabor + batata";


        ArrayList<String> combos = new ArrayList<String>();
        combos.add(nome);
        combos.add(nome1);
        combos.add(nome2);
        combos.add(nome3);
        combos.add(nome4);

        ArrayAdapter<String> adptador = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,combos

        );//fim do arrayadapter

        lista.setAdapter(adptador);

    }
}
