package com.example.pizzarialeprime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class tipos extends AppCompatActivity {


    private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tipos);

        lista = findViewById(R.id.lvtiposID);
        Bundle dado = getIntent().getExtras();
        String nome ="Frago com catupiry";
        String nome1 ="Calabreza";
        String nome2 ="4queijos";
        String nome3 ="Moda da casa";
        String nome4 ="bacon";


        ArrayList<String> bebidas = new ArrayList<String>();
        bebidas.add(nome);
        bebidas.add(nome1);
        bebidas.add(nome2);
        bebidas.add(nome3);
        bebidas.add(nome4);

        ArrayAdapter<String> adptador = new ArrayAdapter<String>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,bebidas

        );//fim do arrayadapter

        lista.setAdapter(adptador);


    }
}
